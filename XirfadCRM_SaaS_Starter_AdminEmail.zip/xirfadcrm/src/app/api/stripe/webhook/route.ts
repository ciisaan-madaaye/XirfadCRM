import { NextResponse } from "next/server";
import { headers } from "next/headers";
import { stripeServer } from "@/lib/stripe";
import { createClient } from "@supabase/supabase-js";
import Stripe from "stripe";

export async function POST(req: Request) {
  const secret = process.env.STRIPE_WEBHOOK_SECRET;
  if (!secret) return NextResponse.json({ error: "Webhook secret lama dejin." }, { status: 500 });
  const body = await req.text();
  const signature = headers().get("stripe-signature");
  if (!signature) return NextResponse.json({ error: "Stripe signature ma jiro." }, { status: 400 });
  let event: Stripe.Event;
  try { event = stripeServer().webhooks.constructEvent(body, signature, secret); }
  catch { return NextResponse.json({ error: "Webhook signature khaldan." }, { status: 400 }); }

  const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const serviceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
  if (!url || !serviceKey) return NextResponse.json({ error: "Deji SUPABASE_SERVICE_ROLE_KEY server-side." }, { status: 500 });
  const admin = createClient(url, serviceKey, { auth: { persistSession: false } });

  if (event.type === "checkout.session.completed") {
    const session = event.data.object as Stripe.Checkout.Session;
    const userId = session.metadata?.user_id || session.client_reference_id;
    const plan = session.metadata?.plan;
    const subscriptionId = typeof session.subscription === "string" ? session.subscription : session.subscription?.id;
    if (userId && (plan === "starter" || plan === "pro") && (session.payment_status === "paid" || session.payment_status === "no_payment_required")) {
      await admin.from("profiles").update({
        plan, subscription_status: "active",
        stripe_customer_id: typeof session.customer === "string" ? session.customer : null,
        stripe_subscription_id: subscriptionId || null
      }).eq("id", userId);
    }
  }
  if (event.type === "customer.subscription.updated" || event.type === "customer.subscription.deleted") {
    const sub = event.data.object as Stripe.Subscription;
    const userId = sub.metadata?.user_id;
    if (userId) {
      const active = sub.status === "active" || sub.status === "trialing";
      await admin.from("profiles").update({
        plan: active ? (sub.metadata?.plan === "pro" ? "pro" : "starter") : "free",
        subscription_status: active ? "active" : "inactive",
        stripe_subscription_id: active ? sub.id : null
      }).eq("id", userId);
    }
  }
  return NextResponse.json({ received: true });
}