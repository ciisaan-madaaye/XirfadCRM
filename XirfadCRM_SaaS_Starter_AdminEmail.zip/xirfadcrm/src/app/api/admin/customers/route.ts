import { NextResponse } from "next/server";
import { cookies } from "next/headers";
import { createServerClient } from "@supabase/ssr";
import { createClient } from "@supabase/supabase-js";

function isOwner(email?: string) {
  const allowed = (process.env.SUPER_ADMIN_EMAILS || "").split(",").map(v => v.trim().toLowerCase()).filter(Boolean);
  return !!email && allowed.includes(email.toLowerCase());
}

export async function PATCH(req: Request) {
  const cookieStore = cookies();
  const supabase = createServerClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!, {
    cookies: { get(name) { return cookieStore.get(name)?.value; } }
  });
  const { data: { user } } = await supabase.auth.getUser();
  if (!user || !isOwner(user.email)) return NextResponse.json({ error: "Maamulka waxaa geli kara milkiilaha oo keliya." }, { status: 403 });

  const { user_id, suspended } = await req.json();
  if (typeof user_id !== "string" || typeof suspended !== "boolean" || user_id === user.id) {
    return NextResponse.json({ error: "Xogta codsiga ma saxna; milkiilaha lama xannibi karo." }, { status: 400 });
  }
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const serviceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
  if (!url || !serviceKey) return NextResponse.json({ error: "Deji SUPABASE_SERVICE_ROLE_KEY server-side." }, { status: 500 });
  const admin = createClient(url, serviceKey, { auth: { persistSession: false } });
  const { error } = await admin.from("profiles").update({ access_suspended: suspended }).eq("id", user_id);
  if (error) return NextResponse.json({ error: error.message }, { status: 500 });
  return NextResponse.json({ ok: true });
}
