import { NextResponse } from "next/server";
import { cookies } from "next/headers";
import { createServerClient } from "@supabase/ssr";
import { createClient } from "@supabase/supabase-js";
import { stripeServer } from "@/lib/stripe";

function isOwner(email?: string) {
  const allowed = (process.env.SUPER_ADMIN_EMAILS || "").split(",").map(v => v.trim().toLowerCase()).filter(Boolean);
  return !!email && allowed.includes(email.toLowerCase());
}

export async function GET() {
  const cookieStore = cookies();
  const supabase = createServerClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!, {
    cookies: { get(name) { return cookieStore.get(name)?.value; } }
  });
  const { data: { user } } = await supabase.auth.getUser();
  if (!user || !isOwner(user.email)) return NextResponse.json({ error: "Maamulka waxaa geli kara milkiilaha oo keliya." }, { status: 403 });

  const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const serviceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
  if (!url || !serviceKey) return NextResponse.json({ error: "Deji SUPABASE_SERVICE_ROLE_KEY server-side." }, { status: 500 });
  const admin = createClient(url, serviceKey, { auth: { persistSession: false } });
  const { data: profiles, error } = await admin.from("profiles")
    .select("id,full_name,plan,subscription_status,access_suspended,stripe_customer_id,created_at")
    .order("created_at", { ascending: false }).limit(500);
  if (error) return NextResponse.json({ error: error.message }, { status: 500 });
  const { data: userPage } = await admin.auth.admin.listUsers({ page: 1, perPage: 500 });
  const emailById = new Map((userPage?.users || []).map(account => [account.id, account.email || ""]));

  let collectedThisMonth = 0;
  let invoiceNote = "";
  try {
    const stripe = stripeServer();
    const now = new Date();
    const monthStart = Math.floor(new Date(now.getFullYear(), now.getMonth(), 1).getTime() / 1000);
    const invoices = await stripe.invoices.list({ status: "paid", created: { gte: monthStart }, limit: 100 });
    collectedThisMonth = invoices.data.reduce((sum, invoice) => sum + invoice.amount_paid, 0) / 100;
    if (invoices.has_more) invoiceNote = "Waxaa la tiriyey 100-ka invoice ee ugu dambeeya bishan; waxaa jiri kara invoice-yo dheeraad ah.";
  } catch {
    invoiceNote = "Stripe lama dejin ama xogta invoice-ka lama heli karin.";
  }

  const all = profiles || [];
  return NextResponse.json({
    customers: all.map(p => ({ ...p, email: emailById.get(p.id) || "" })),
    totals: {
      registered: all.length,
      activePaid: all.filter(p => p.subscription_status === "active" && ["starter", "pro"].includes(p.plan) && !p.access_suspended).length,
      suspended: all.filter(p => p.access_suspended).length,
      starter: all.filter(p => p.plan === "starter" && p.subscription_status === "active").length,
      pro: all.filter(p => p.plan === "pro" && p.subscription_status === "active").length,
      collectedThisMonth
    },
    invoiceNote
  });
}
